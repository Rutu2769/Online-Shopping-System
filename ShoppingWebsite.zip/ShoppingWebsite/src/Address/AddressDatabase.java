package Address;

import java.util.Set;

public class AddressDatabase {
    private Set<String> address;
}
