package Main;

import User.User;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        User user = new User();
        int choice = 0;
        do {
            System.out.println("""
                    CHOOSE ONE OF THE FOLLOWING
                    1.LOGIN
                    2.SIGNUP
                    ANY OTHER KEY TO EXIT""");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:{
                    System.out.println("ENTER YOUR USERNAME");
                    user.enterUserName(scanner.nextLine());
                    break;
                }

                case 2:{
                    user.setData();
                    break;
                }

                default: {
                    System.out.println("EXITED");
                }
            }
        }while (choice == 1 || choice == 2);
    }
}