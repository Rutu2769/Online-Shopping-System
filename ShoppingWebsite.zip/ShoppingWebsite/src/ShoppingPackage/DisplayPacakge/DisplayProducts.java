package ShoppingPackage.DisplayPacakge;

import CartPackage.Cart;
import ShoppingPackage.UserOrder;

import java.util.Scanner;

public class DisplayProducts {
    Cart cart = new Cart();

    public void listOfProducts() {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;

        System.out.println("""
                CHOOSE ONE OF THE PRODUCTS
                1.Cloth
                2.Beauty Product
                3.Electronics
                4.DISPLAY CART
                5.CHECK OUT""");
        choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1 -> listOfCloths();
            case 2 -> System.out.println("HYGIENE");
            case 3 -> System.out.println("OIL");
            case 4 -> cart.displayCart();
            case 5 -> cart.billMe();
            default -> System.out.println("INVALID CHOICE");
        }
    }

    public void listOfCloths() {

        Scanner scanner = new Scanner(System.in);
        int choice = 1;

        while (choice == 1 || choice == 2) {
            System.out.println("""
                CHOOSE ONE OF THE PRODUCTS
                1.Top
                2.Jeans
                3.GO BACK
                """);
            choice = scanner.nextInt();
            scanner.nextLine();
            UserOrder userOrder=new UserOrder();

            switch (choice) {
                case 1 -> cart.addProduct(userOrder.yourTopOrders());
                case 2 -> cart.addProduct(userOrder.yourJeansOrders());
                case 3 -> listOfProducts();
                default -> System.out.println("INVALID CHOICE");
            }
        }
    }

//    public void listOfBeautyProducts()
//    {
//      Scanner scanner=new Scanner(System.in);
//    int choice=1;
//    while (choice==1||choice==2||choice==3)
//    {
//        System.out.println("""
//                    CHOOSE ONE OF THE PRODUCTS
//                    1.Eyeliner
//                    2.Lipstick
//                    3.Foundation
//                    4.Go Back
//                """);
//        choice = scanner.nextInt();
//        scanner.nextLine();
//        UserOrder userOrder=new UserOrder();
//
//        switch (choice) {
//            case 1 -> cart.addProduct(userOrder.());
//            case 2 -> cart.addProduct(userOrder.yourJeansOrders());
//            case 4 -> listOfProducts();
//            default -> System.out.println("INVALID CHOICE");
//        }
//    }

//    }
}
