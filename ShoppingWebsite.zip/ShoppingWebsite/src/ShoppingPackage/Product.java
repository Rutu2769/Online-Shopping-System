package ShoppingPackage;

import ShoppingPackage.ClothPackage.Cloth;
import ShoppingPackage.BeautyProductPackage.BeautyProduct;
import ShoppingPackage.ElectroincsPackage.Electronic;

public class Product {
    private Cloth cloth;
    private Electronic electronic;
    private BeautyProduct beautyProduct;

    public double getPrice() {
        return 0;
    }

    @Override
    public String toString() {
        return "Product{" +
                "cloth=" + cloth +
                ", electronic=" + electronic +
                ", beautyProduct=" + beautyProduct +
                '}';
    }
}
