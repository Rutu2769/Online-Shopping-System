package ShoppingPackage.ElectroincsPackage;

public class Laptop extends Electronic {
    public Laptop(String brand, double quantity, double price) {
        super(brand, quantity, price);
    }

    public double getPrice()
    {
       if(brand=="Dell"||brand=="Lenovo" || brand=="HP")
       {
           return 60*this.quantity;
       }
       else
       {
           return 30*this.quantity;
       }
    }
}
