package ShoppingPackage.ElectroincsPackage;


import ShoppingPackage.Product;

public class Electronic extends Product {

    protected String brand;
    protected double quantity;
    protected double price;

    public Electronic(String brand, double quantity, double price) {
        this.brand = brand;
        this.quantity = quantity;
        this.price = price;
    }

    public Electronic() {
    }

    public double getPrice() {
        return 10;
    }
    @Override
    public String toString() {
        return "Electronic{" +
                "brand='" + brand + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                '}';
    }
}
