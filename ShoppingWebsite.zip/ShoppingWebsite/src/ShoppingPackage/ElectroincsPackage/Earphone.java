package ShoppingPackage.ElectroincsPackage;

public class Earphone extends Electronic {

    public Earphone(String brand, double quantity, double price) {
        super(brand, quantity, price);
    }
    public double getPrice()
    {
        return 90*this.quantity;
    }
}
