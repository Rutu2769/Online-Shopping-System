package ShoppingPackage.ElectroincsPackage;

public class Speaker extends Electronic {

    public Speaker(String brand, double quantity, double price) {
        super(brand, quantity, price);
    }

    public double getPrice()
    {
        return 90*this.quantity;
    }
}
