package ShoppingPackage.BeautyProductPackage;

public class Eyeliner extends BeautyProduct{
    public Eyeliner(String brand, double quantity, double price) {
        super(brand, quantity, price);
    }

    public double getPrice() {
        return 10 * this.quantity;
    }
}
