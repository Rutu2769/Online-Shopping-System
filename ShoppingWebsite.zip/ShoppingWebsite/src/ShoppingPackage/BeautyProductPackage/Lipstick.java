package ShoppingPackage.BeautyProductPackage;

public class Lipstick extends BeautyProduct{
    public Lipstick(String brand, double quantity, double price) {
        super(brand, quantity, price);
    }
    public double getPrice() {
        return 20 * this.quantity;
    }
}
