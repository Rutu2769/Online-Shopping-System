package ShoppingPackage.BeautyProductPackage;

public class Foundation extends BeautyProduct{
    public Foundation(String brand, double quantity, double price) {
        super(brand, quantity, price);
    }
    public double getPrice() {
        return 50 * this.quantity;
    }
}
