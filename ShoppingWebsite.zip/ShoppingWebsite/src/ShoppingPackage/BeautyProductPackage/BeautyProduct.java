
package ShoppingPackage.BeautyProductPackage;

import ShoppingPackage.Product;

public class BeautyProduct extends Product{

    protected String brand;
    protected double quantity;
    protected double price;

    public BeautyProduct(String brand, double quantity, double price) {
        this.brand = brand;
        this.quantity = quantity;
        this.price = price;
    }

    public BeautyProduct() {
    }

    public double getPrice() {
        return 10;
    }

    @Override
    public String toString() {
        return "BeautyProduct{" +
                "brand='" + brand + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                '}';
    }
}
