package ShoppingPackage;

import ShoppingPackage.ClothPackage.Jeans;
import ShoppingPackage.ClothPackage.Top;

import java.util.Scanner;
public class UserOrder{



    public Product yourTopOrders()
    {
        Scanner scanner=new Scanner(System.in);
        System.out.println("ENTER BRAND NAME");
        String brand=scanner.nextLine();
        System.out.println("ENTER QUANTITY");
        double quantity=scanner.nextDouble();
        scanner.nextLine();
        System.out.println("ENTER Gender");
        String gender=scanner.nextLine();
        Top top=new Top(brand,quantity,gender);
        return top;
    }

    public Product yourJeansOrders()
    {
        Scanner scanner=new Scanner(System.in);
        System.out.println("ENTER BRAND NAME");
        String brand=scanner.nextLine();
        System.out.println("ENTER QUANTITY");
        double quantity=scanner.nextDouble();
        scanner.nextLine();
        System.out.println("ENTER Gender");
        String gender=scanner.nextLine();
        Jeans jeans=new Jeans(brand,quantity,gender);
        return jeans;
    }




}

