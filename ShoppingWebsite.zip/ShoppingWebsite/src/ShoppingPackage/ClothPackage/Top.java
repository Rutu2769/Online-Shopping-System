package ShoppingPackage.ClothPackage;
public class Top extends Cloth {
    public Top(String brand, double quantity,String gender) {
        super(brand, quantity,gender);
    }

    public double getPrice() {
        return 50* this.quantity;
    }
}

