package ShoppingPackage.ClothPackage;

public class Jeans extends Cloth {
    public Jeans(String brand, double quantity, String gender) {
        super(brand, quantity, gender);
    }

    public double getPrice() {
        return 10 * this.quantity;
    }
}

