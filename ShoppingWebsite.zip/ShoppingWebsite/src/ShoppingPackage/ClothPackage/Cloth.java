package ShoppingPackage.ClothPackage;

import ShoppingPackage.Product;

public class Cloth extends Product {

    protected String brand;
    protected double quantity;
    protected String gender;

    public Cloth(String brand, double quantity, String gender) {
        this.brand = brand;
        this.quantity = quantity;
        this.gender = gender;
    }

    public Cloth() {

    }

    public double getPrice() {
        return 10;
    }

    @Override
    public String toString() {
        return "Dairy{" +
                "brand='" + brand + '\'' +
                ", quantity=" + quantity +
                ", gender='" + gender + '\'' +
                '}';
    }
}
