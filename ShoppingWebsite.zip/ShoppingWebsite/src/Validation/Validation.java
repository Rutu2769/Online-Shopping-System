package Validation;

public class Validation {
    static public boolean isPhoneNumberValid(String phoneNumber)
    {
        return phoneNumber.matches("[7-9][0-9]{9}");
    }
    static public boolean isFirstNameValid(String firstname)
    {
        return firstname.matches("^[A-Za-z]\\w{1,29}$");
    }
    static public boolean isLastNameValid(String lastname)
    {
        return lastname.matches("^[A-Za-z]\\w{1,29}$");
    }

    public static boolean isPasswordValid(String password)
    {
        return password.matches("^(?=.*[0-9])"
                + "(?=.*[a-z])(?=.*[A-Z])"
                + "(?=.*[@#$%^&+=])"
                + "(?=\\S+$).{8,20}$");
    }

    public static boolean isEmailValid(String password)
    {
        return password.matches("^(.+)@(.+)$");
    }
    static public boolean isValidPinCode(String pinCode)
    {
        if(pinCode.contains("000000"))
        {
            return false;
        }
        else return pinCode.matches("[0-9]{6}");
    }
    static public boolean isValidStreetName(String streetName)
    {
        return streetName.matches("^[A-Za-z]\\w{1,50}$");
    }
    static public boolean isValidCityName(String city)
    {
        return city.matches("^[A-Za-z]\\w{1,29}$");
    }
}