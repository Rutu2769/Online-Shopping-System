package CartPackage;

import ShoppingPackage.Product;

import java.util.ArrayList;
import java.util.List;

public class Cart<T extends Product> {
    static List<Product> products;
    public void addProduct(T p) {
        if (products == null) {
            List<Product> newList = new ArrayList<>();
            newList.add(p);
            products = newList;
        } else {
            products.add(p);
        }
    }
    public void displayCart() {
        System.out.println(products);
    }

    public void billMe() {
        double sum = 0;
        for (var p : products) {
            sum = sum + p.getPrice();
        }
        System.out.println(sum);
    }
}
