package Signup;

import Address.Address;
import User.User;
import User.UserDatabase;
import Validation.Validation;

import java.util.Map;
import java.util.Scanner;

public class Signup {
    public void enterUserData(User user) {
        Scanner scanner = new Scanner(System.in);
        Address address = new Address();
        boolean flag = true;

        while (flag) {
            System.out.println("ENTER YOUR FIRST NAME");
            String firstName = scanner.nextLine();
            if (Validation.isFirstNameValid(firstName)) {
                user.setFirstName(firstName);
                flag = false;
            }else {
                System.out.println("INVALID FIRST NAME");
            }
        }

        flag = true;
        while (flag) {
            System.out.println("ENTER YOUR LAST NAME");
            String lastName = scanner.nextLine();
            if (Validation.isLastNameValid(lastName)) {
                user.setLastName(lastName);
                flag = false;
            }else {
                System.out.println("INVALID LAST NAME");
            }
        }

        flag = true;
        while (flag) {
            System.out.println("ENTER YOUR USERNAME");
            String userName = scanner.nextLine();
            Map<String, User> allUserMap = UserDatabase.getUserMap();
            if (allUserMap == null) {
                user.setUserName(userName);
                flag = false;
            }else {
                for (Map.Entry<String, User> individualUser : allUserMap.entrySet()) {
                    if (!individualUser.getKey().equals(userName)) {
                        user.setUserName(userName);
                        flag = false;
                    }else {
                        System.out.println("USERNAME ALREADY PRESENT");
                    }
                }
            }
        }

        flag = true;
        while (flag) {
            System.out.println("ENTER YOUR PHONE NUMBER");
            String phoneNumber = scanner.nextLine();
            if (Validation.isPhoneNumberValid(phoneNumber)) {
                user.setPhoneNumber(phoneNumber);
                flag = false;
            }else {
                System.out.println("INVALID PHONE NUMBER");
            }
        }

        flag = true;
        while (flag) {
            System.out.println("ENTER YOUR EMAIL ADDRESS");
            String email = scanner.nextLine();
            if (Validation.isEmailValid(email)) {
                user.setEmail(email);
                flag = false;
            }else {
                System.out.println("INVALID EMAIL");
            }
        }

        flag = true;
        while (flag) {
            System.out.println("ENTER NEW PASSWORD");
            String password = scanner.nextLine();
            if (Validation.isPasswordValid(password)) {
                user.setPassword(password);
                flag = false;
            }else {
                System.out.println("INVALID PASSWORD");
            }
        }

        flag = true;
        while (flag) {
            System.out.println("ENTER YOUR STREET NAME");
            String streetName = scanner.nextLine();
            if (Validation.isValidStreetName(streetName)) {
                address.setStreetAddress(streetName);
                flag = false;
            }else {
                System.out.println("INVALID STREET NAME");
            }
        }

        flag = true;
        while (flag) {
            System.out.println("ENTER YOUR CITY NAME");
            String cityName = scanner.nextLine();
            if (Validation.isValidCityName(cityName)) {
                address.setCity(cityName);
                flag = false;
            }else {
                System.out.println("INVALID CITY");
            }
        }

        flag = true;
        while (flag) {
            System.out.println("ENTER YOUR PIN CODE");
            String pinCode = scanner.nextLine();
            if (Validation.isValidPinCode(pinCode)) {
                address.setPinCode(pinCode);
                flag = false;
            }else {
                System.out.println("INVALID PIN CODE");
            }
        }
        user.setAddress(address);

        UserDatabase.setUserMap(user.getUserName(), user);
        System.out.println("SIGNUP SUCCESSFUL");
    }
}