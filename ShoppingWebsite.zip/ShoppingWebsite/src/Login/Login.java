package Login;

import ShoppingPackage.DisplayPacakge.DisplayProducts;
import User.User;
import User.UserDatabase;

import java.io.File;
import java.util.Map;
import java.util.Scanner;

public class Login {
    public void checkValidUserName(String userName) {
        Scanner scanner = new Scanner(System.in);
        DisplayProducts displayProducts = new DisplayProducts();

        Map<String, User> allUserMap = UserDatabase.getUserMap();
        if (allUserMap != null) {
            for (Map.Entry<String, User> individualUser : allUserMap.entrySet()) {
                if (individualUser.getKey().equals(userName)) {
                    System.out.println("ENTER YOUR PASSWORD");
                    String enteredPassword = scanner.nextLine();
                    if (individualUser.getValue().getPassword().equals(enteredPassword)) {
                        System.out.println("LOGIN SUCCESSFUL");
                        displayProducts.listOfProducts();
                    }else {
                        System.out.println("INVALID PASSWORD");
                    }
                }else {
                    System.out.println("INVALID USERNAME");
                }
            }
        }else {
            File file = new File("UserDetails.txt");
        }
    }
}
