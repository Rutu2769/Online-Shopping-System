package User;

import ReadAndWriteOperation.ReadAndWriteData;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class UserDatabase implements Serializable {
    private static Map<String, User> userMap = new HashMap<>();

    public static Map<String, User> getUserMap() {
        ReadAndWriteData readAndWriteData = new ReadAndWriteData();
        Map<String, User> obtainedUserMap = readAndWriteData.readFile();
        return obtainedUserMap;
    }

    public static void setUserMap(String userName, User user) {
        ReadAndWriteData readAndWriteData = new ReadAndWriteData();
        userMap.put(userName, user);
        readAndWriteData.writeFile(userMap);
    }
}