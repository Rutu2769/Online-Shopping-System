package ReadAndWriteOperation;

import User.User;

import java.io.*;
import java.util.Map;

public class ReadAndWriteData {
    File file = new File("UserDetails.txt");
    public void writeFile(Map<String, User> personMap) {
        try(FileOutputStream fileOutputStream = new FileOutputStream(file);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)) {
            objectOutputStream.writeObject(personMap);
        } catch (IOException ignored) {
        }
    }

    public Map<String, User> readFile() {
        Map<String, User> personMap = null;
        try(FileInputStream fileInputStream = new FileInputStream("UserDetails.txt");
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream)) {
            personMap = (Map<String, User>) objectInputStream.readObject();
        } catch (IOException | ClassNotFoundException ignored) {
        }
        return personMap;
    }
}
